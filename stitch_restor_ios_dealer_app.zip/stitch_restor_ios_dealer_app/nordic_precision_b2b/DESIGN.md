---
name: Nordic Precision B2B
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f7'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#191c1e'
  on-surface-variant: '#43474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f4'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4c6077'
  primary: '#001021'
  on-primary: '#ffffff'
  primary-container: '#10263a'
  on-primary-container: '#798ea6'
  inverse-primary: '#b3c9e3'
  secondary: '#31618f'
  on-secondary: '#ffffff'
  secondary-container: '#9dcafe'
  on-secondary-container: '#225583'
  tertiary: '#081016'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d252c'
  on-tertiary-container: '#848c94'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cfe5ff'
  primary-fixed-dim: '#b3c9e3'
  on-primary-fixed: '#051d31'
  on-primary-fixed-variant: '#34485e'
  secondary-fixed: '#d0e4ff'
  secondary-fixed-dim: '#9dcafe'
  on-secondary-fixed: '#001d35'
  on-secondary-fixed-variant: '#114976'
  tertiary-fixed: '#dbe3ec'
  tertiary-fixed-dim: '#bfc7d0'
  on-tertiary-fixed: '#151c23'
  on-tertiary-fixed-variant: '#40484f'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e6'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 41px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers an executive, Apple-grade B2B platform tailored for enterprise hardware dealers, wholesale distributors, and retail partners. Blending the surgical precision of modern medical interfaces with the refined clarity of iOS Human Interface Guidelines, the aesthetic is clean, disciplined, and frictionless.

The interface prioritizes high-stakes business commerce: bulk pricing transparency, stock confidence, and streamlined requisition workflows. The tone avoids loud consumer retail tropes in favor of quiet authority, balanced proportions, and functional elegance. Visual weight is carried through crisp contrast, deep ink tones, and subtle 1px structural framing rather than heavy shadows or hyper-saturated accents.

## Colors

The palette establishes an authoritative hierarchy rooted in deep maritime navy and technical slate neutrals.

- **Primary Canvas & Surfaces**: The base application background is set to a crisp, clinical soft grey (`#F3F5F8`), providing high contrast against elevated pure white cards (`#FFFFFF`).
- **Primary Navy (`#10263A`)**: Anchors critical touchpoints including primary call-to-action buttons, active navigation pills, and header bar containers.
- **Brand Blue (`#174D7A`)**: Used for contextual interactive links, focused states, and prominent iconography.
- **Pale Blue Soft Fill (`#EAF2FB`)**: Provides background tinting for informational cards, active filter tags, discount pill containers, and tertiary interaction fields.
- **Structural Borders (`#DCE4ED`)**: Precise 1px borders delineating card groups and list partitions without visual clutter.
- **Typography Tones**: Primary headers and values leverage deep ink (`#152334`), while secondary captions, unit counters, and metadata utilize slate (`#64748B`).
- **Functional Semantics**: Verified status badges and approved wholesale margins use verified emerald (`#16834A`); volume alerts and tiered quota milestones apply balanced warning amber (`#C98616`).

## Typography

The typography is built around Plus Jakarta Sans to mirror native iOS SF Pro rhythm and geometric clarity. 

- **Numerical Display**: Wholesale prices, stock SKU units, and order totals apply tabular figures (`tnum`) for flawless vertical scanning in dealer tables.
- **Hierarchy Rules**: Screen titles leverage bold primary ink (`#152334`) at 24–28px, maintaining compact line heights for mobile density. Subheaders and section eyebrows use uppercase 11px medium labels with +0.5px letter tracking.
- **Dealer Specs**: Technical specs (voltages, finishes, carton sizes) use `body-sm` (`13px`) set to `#64748B` to keep focus on price margins and inventory availability.

## Layout & Spacing

Layout adheres strictly to an 8-point base grid (subdivided to 4pt for micro-offsets) to support ergonomic one-handed mobile dealer navigation.

- **Canvas Structure**: Standard mobile screens utilize a 16px (`1rem`) outer lateral margin. Internal card padding ranges from 16px to 20px, ensuring content breathes cleanly within bounded containers.
- **Vertical Rhythm**: Section groups are separated by 20–24px gaps. Form inputs and field stacks preserve a 12px vertical spacing cadence.
- **Touch Targets**: All tappable elements, icon buttons, filter toggles, and carousel bullets conform to Apple's 44x44pt minimum interactable bounding box, irrespective of visual icon glyph size.
- **Bottom Navigation Dock**: Floating or tab-docked navigation maintains a minimum safe-area padding of 34px on home indicator devices, preserving visibility above scrolling lists.

## Elevation & Depth

Visual hierarchy relies on structural tonal separation rather than heavy skeuomorphic shadows, inspired by clean clinical and Apple-native UI structures.

- **Base to Card Separation**: Pure `#FFFFFF` surfaces sit directly over the `#F3F5F8` canvas, bordered by a hairline 1px `#DCE4ED` stroke. Shadows are kept exceptionally faint: `0 2px 8px rgba(16, 38, 58, 0.04)`.
- **Floating Controls & Modals**: Bottom sheets, quick-action contact bars, and bottom navigation pods leverage higher elevation with a soft, diffused drop shadow: `0 8px 24px rgba(16, 38, 58, 0.08)` accompanied by the standard 1px border.
- **Active & Pressed Depth**: Interactive cards depress slightly (`scale(0.985)`) on mobile touch down, providing immediate tactile response without heavy skeuomorphism.

## Shapes

The design uses balanced, rounded geometry. Standard card surfaces, catalog tiles, and action containers utilize a uniform 18px to 20px radius, mirroring the visual language of the reference layout.

Secondary elements—such as buttons, text entry fields, and floating bottom navigation tabs—feature fully pill-shaped or smooth continuous 12–14px curvature to reinforce touch-friendly ergonomics. Status badges, stock tags, and scheme counter pills feature circular full-capsule radii (9999px).

## Components

### Buttons & Action Bars
- **Primary CTA**: Solid `#10263A` navy background, white text, 14px radius or 48px pill height. Right-aligned circular icon accessory (`#FFFFFF` background with navy arrow glyph) for forward actions.
- **Secondary Action**: Bordered 1px `#DCE4ED` with pure `#FFFFFF` background and `#10263A` text.
- **Direct Dealer Call Bar**: Integrated floating contact dock spanning full width or docked to the bottom nav, featuring phone icon, phone number, and a contrasting pill label.

### Cards & Catalogs
- **Product Tile**: White background, 18px border-radius, 1px `#DCE4ED` border. Top section houses product asset photography centered with ample white space; heart/favorite button floats in the top-right corner inside an elevated white circle.
- **Pricing & Scheme Tier**: Delineated with a subtle dashed divider line. Features bold primary currency display (`#152334`) paired with an informative "Scheme Available" pill badge in `#EAF2FB` with `#174D7A` text.

### Chips & Filter Pills
- **Inactive**: Solid `#FFFFFF` fill with 1px `#DCE4ED` stroke, `#64748B` typography.
- **Active / Selected**: `#10263A` solid fill with white text, or `#EAF2FB` fill with `#174D7A` bold text for contextual multi-select options.

### Input Fields & Search
- **Search Bar**: 44px height, light background `#FFFFFF` or `#EAF2FB`, 12px radius, left-aligned search icon, right-aligned filter button framed in a rounded border.
- **Quantity Selector**: Stepper controls (`-`, value, `+`) enclosed in a pill border with 36px minimum touch targets per button.

### Bottom Navigation Bar
- High-contrast floating pill dock at bottom viewport with white surface, rounded-3xl profile, and 1px `#DCE4ED` border.
- Active item displays an inverted deep navy pill (`#10263A`) containing white icon and title, while inactive icons sit in `#64748B` with subtle label typography.